package sql_codigo

import cats.effect.IO
import doobie.*
import doobie.implicits.*
import utilidades.Connector.xa // Importamos el transactor

object Consultas {
  @main
  def obtenerUserId(id: Int): IO[Option[String]] = {
    sql"SELECT * FROM prueba.keywords;"
      .query[String]
      .option
      .transact(xa)
  }

}
