package sql_codigo

import doobie._
import doobie.implicits._

import cats.effect.unsafe.implicits.global
import cats.effect._

import cats.implicits._

import movie_case_class._
import utilidades.Connector

object codigo {

  def insert(est: movie_table): ConnectionIO[Int] = {
    sql"""
       INSERT INTO movie (id, adult, budget, homepage, imdb_id,
       original_language, original_title, overview, popularity, poster_path,
       release_date, revenue, runtime, status, tagline, title, video, vote_average, vote_count)
       VALUES (
         ${est.id},
         ${est.adult},
         ${est.budget},
         ${est.homepage},
         ${est.imdb_id},
         ${est.original_language},
         ${est.original_title},
         ${est.overview},
         ${est.popularity},
         ${est.poster_path},
         CASE WHEN ${est.release_date} = 'NULL' THEN NULL ELSE ${est.release_date} END,
         ${est.revenue},
         ${est.runtime},
         CASE WHEN LENGTH(${est.status}) > 50 THEN NULL ELSE ${est.status} END,
         ${est.tagline},
         ${est.title},
         ${est.video},
         ${est.vote_average},
         ${est.vote_count}
       )
     """.update.run
  }

  //FUNCION PARA METER UNA LISTA DE OBJETOS A UNA DB
  def insertAll(est: List[movie_table]): IO[List[Int]] = {
    est.traverse(t => insert(t).transact(Connector.xa))
  }
}


  /*
  //FUNCION PARA TRAER UNA LISTA DE OBJETOS A LA DB
  def lista_estudiantes(): ConnectionIO[List[movie]] =
    sql"SELECT nombre, edad, calificacion, genero FROM Estudiante"
      .query[movie]
      .to[List]
   */

