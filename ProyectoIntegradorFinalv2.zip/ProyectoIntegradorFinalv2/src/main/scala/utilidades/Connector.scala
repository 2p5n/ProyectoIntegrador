package utilidades

import doobie.*
import doobie.implicits.*

import cats.*
import cats.effect.*
import cats.implicits.*
import cats.effect.unsafe.implicits.global

object Connector {

  val xa = Transactor.fromDriverManager[IO](
    driver = "com.mysql.cj.jdbc.Driver", // JDBC driver
    url = "jdbc:mysql://localhost:3306/prueba", // URL de conexión
    user = "user", // Nombre de la base de datos
    password = "", // Password
    logHandler = None // Manejo de la información de Log
  )
}