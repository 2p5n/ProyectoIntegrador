package limpieza_inserts

import com.github.tototoshi.csv.{CSVReader, DefaultCSVFormat}
import json_case_class.Cast
import play.api.libs.json.*
import utilidades.EscapeCaracteresEspeciales.limpiarJsonCrew

import java.io.{File, PrintWriter}
import scala.collection.mutable.ListBuffer
import scala.util.{Failure, Success, Try}

object Cast extends App {
  val rutaCsv = "data/pi_movies_complete.csv"
  val rutaArchivoSql = "data/inserts_cast.sql"

  implicit val csvFormat: DefaultCSVFormat = new DefaultCSVFormat {
    override val delimiter = ';'
  }

  val reader = CSVReader.open(new File(rutaCsv))
  val writer = new PrintWriter(new File(rutaArchivoSql))

  try {
    val datos = reader.allWithHeaders()

    val datosFiltrados = datos.filter { fila =>
      val columnasExcluyendoId = fila - "id"
      columnasExcluyendoId.values.exists(_.trim.nonEmpty) &&
        !columnasExcluyendoId.values.forall(_.trim.toLowerCase == "<unset>")
    }.distinct

    println(s"Total de filas después de filtrar: ${datosFiltrados.size}")

    val actorsList = new ListBuffer[Cast]()
    val movieActorsList = new ListBuffer[(Int, Int, String, Int, Int, String)]()

    datosFiltrados.foreach { fila =>
      for {
        movieId <- Try(fila("id").trim.toInt).toOption
        jsonStr = fila.getOrElse("cast", "").trim if jsonStr.nonEmpty && jsonStr != "\"\""
        jsonLimpio = limpiarJsonCrew(jsonStr).replaceAll("'", "\"")
        jsonArray <- Try(Json.parse(jsonLimpio).as[List[JsObject]]).toOption
      } jsonArray.foreach { jsonObj =>
        jsonObj.validate[Cast] match {
          case JsSuccess(cast, _) =>
            actorsList += cast
            movieActorsList += ((movieId, cast.id, cast.character, cast.order, cast.cast_id, cast.credit_id))
          case JsError(errors) =>
            println(s"Error en el cast JSON: $errors")
        }
      }
    }

    try {
      writer.println("-- Inserts para la tabla actors")
      actorsList.groupBy(_.id).foreach { case (idActor, castList) =>
        val cast = castList.head
        val nameEscaped = cast.name.replace("'", "''")
        val profilePathEscaped = Option(cast.profile_path).getOrElse("").replace("'", "''")
        val gender = cast.gender

        writer.println(
          s"INSERT INTO actors (id_actors, actors_name, gender, profile_path) VALUES ($idActor, '$nameEscaped', $gender, '$profilePathEscaped');"
        )
      }

      writer.println("\n-- Inserts para la tabla movieActors")
      movieActorsList.distinct.foreach { relation =>
        writer.println(s"INSERT INTO movieActors (movie_id, id_actors, character1, order1, cast_id, credit_id) VALUES (${relation._1}, ${relation._2}, '${relation._3}', ${relation._4}, ${relation._5}, '${relation._6}');")
      }

      println("Archivo SQL generado exitosamente: inserts_cast.sql")
    } catch {
      case e: Exception => println(s"Error al escribir el archivo SQL: ${e.getMessage}")
    } finally {
      writer.close()
    }

  } catch {
    case e: Exception => println(s"Error crítico: ${e.getMessage}")
  } finally {
    reader.close()
  }
}