package limpieza_inserts

import com.github.tototoshi.csv.{CSVReader, DefaultCSVFormat}
import json_case_class.Country
import play.api.libs.json.*
import utilidades.EscapeCaracteresEspeciales.limpiarJson

import java.io.{File, PrintWriter}
import scala.collection.mutable.ListBuffer
import scala.util.{Failure, Success, Try}

object Production_countries extends App {
  val rutaCsv = "data/pi_movies_complete.csv"
  val rutaArchivoSql = "data/inserts_production_countries.sql"

  implicit val csvFormat: DefaultCSVFormat = new DefaultCSVFormat {
    override val delimiter = ';'
  }

  val reader = CSVReader.open(new File(rutaCsv))
  val writer = new PrintWriter(new File(rutaArchivoSql))

  try {
    val datos = reader.allWithHeaders()

    val datosFiltrados = datos.filter { fila =>
      val columnasExcluyendoId = fila - "id"
      columnasExcluyendoId.values.exists(_.trim.nonEmpty) &&
        !columnasExcluyendoId.values.forall(_.trim.toLowerCase == "<unset>")
    }.distinct

    println(s"Total de filas después de filtrar: ${datosFiltrados.size}")

    val countriesList = new ListBuffer[Country]()
    val movieCountriesList = new ListBuffer[(Int, String)]()

    datosFiltrados.foreach { fila =>
      for {
        movieId <- Try(fila("id").trim.toInt).toOption
        jsonStr = fila.getOrElse("production_countries", "").trim if jsonStr.nonEmpty && jsonStr != "\"\""
        jsonLimpio = limpiarJson(jsonStr).replaceAll("'", "\"")
        jsonArray <- Try(Json.parse(jsonLimpio).as[JsArray]).toOption
      } jsonArray.value.foreach {
        case jsObj: JsObject =>
          (jsObj \ "iso_3166_1").asOpt[String].foreach { iso =>
            val countryName = (jsObj \ "name").asOpt[String].getOrElse("null")
            val country = Country(iso, countryName)
            countriesList += country
            movieCountriesList += ((movieId, iso))
          }
        case _ => println(s"Formato inesperado en JSON de production_countries: $jsonLimpio")
      }
    }

    try {
      writer.println("-- Inserts para la tabla countries")
      countriesList.distinct.foreach { country =>
        val nameEscaped = country.name.replace("'", "''")
        writer.println(s"INSERT INTO countries (iso_3166_1, countries_name) VALUES ('${country.iso_3166_1}', '$nameEscaped');")
      }

      writer.println("\n-- Inserts para la tabla movie_countries")
      movieCountriesList.distinct.foreach { case (movieId, iso) =>
        writer.println(s"INSERT INTO movie_countries (movie_id, iso_3166_1) VALUES ($movieId, '$iso');")
      }

      println("Archivo SQL generado exitosamente: inserts_production_countries.sql")
    } catch {
      case e: Exception => println(s"Error al escribir el archivo SQL: ${e.getMessage}")
    } finally {
      writer.close()
    }

  } catch {
    case e: Exception => println(s"Error crítico: ${e.getMessage}")
  } finally {
    reader.close()
    }
}