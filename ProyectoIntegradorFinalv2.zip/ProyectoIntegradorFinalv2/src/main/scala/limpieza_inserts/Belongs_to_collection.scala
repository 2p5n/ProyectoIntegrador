package limpieza_inserts

import com.github.tototoshi.csv.{CSVReader, DefaultCSVFormat}
import json_case_class.BelongsToCollection
import play.api.libs.json.*
import utilidades.EscapeCaracteresEspeciales.limpiarJsonCrew

import java.io.{File, PrintWriter}
import scala.util.{Failure, Success, Try}

object Belongs_to_collection extends App {
  val rutaCsv = "data/pi_movies_complete.csv"
  val rutaArchivoSql = "data/inserts_belongs_to_collection.sql"

  implicit val csvFormat: DefaultCSVFormat = new DefaultCSVFormat {
    override val delimiter = ';'
  }

  val reader = CSVReader.open(new File(rutaCsv))
  val writer = new PrintWriter(new File(rutaArchivoSql))

  try {
    val datos = reader.allWithHeaders()

    val datosFiltrados = datos.filter { fila =>
      val columnasExcluyendoId = fila - "id"
      columnasExcluyendoId.values.exists(_.trim.nonEmpty) &&
        !columnasExcluyendoId.values.forall(_.trim.toLowerCase == "<unset>")
    }.distinct

    println(s"Total de filas después de filtrar: ${datosFiltrados.size}")

    def parsearJson[T](jsonStr: String)(implicit reads: Reads[T]): Option[T] = {
      Try(Json.parse(jsonStr).as[T]).toOption
    }

    val belongsToCollectionData = datosFiltrados.flatMap { fila =>
      for {
        movieId <- Try(fila("id").trim.toInt).toOption
        jsonStr = fila.getOrElse("belongs_to_collection", "").trim if jsonStr.nonEmpty && jsonStr != "\"\""
        jsonLimpio = limpiarJsonCrew(jsonStr).replaceAll("'", "\"")
        jsonObj <- Try(Json.parse(jsonLimpio).validate[JsObject]).toOption.collect { case JsSuccess(obj, _) => obj }
        id <- (jsonObj \ "id").asOpt[Int]
        name = (jsonObj \ "name").asOpt[String].filter(_.nonEmpty).getOrElse("null")
        posterPath = (jsonObj \ "poster_path").asOpt[String].filter(_.nonEmpty).getOrElse("null")
        backdropPath = (jsonObj \ "backdrop_path").asOpt[String].filter(_.nonEmpty).getOrElse("null")
        collection = BelongsToCollection(id, name, posterPath, backdropPath)
      } yield (movieId, collection)
    }.distinct
    val distinctData = belongsToCollectionData.distinctBy(_._1).distinctBy(identity)
    distinctData.foreach { case (_, collection) =>
      writer.println(s"INSERT INTO belongs_to_collection (collection_id, collection_name, collection_poster_path, collection_backdrop_path) VALUES (${collection.id}, '${collection.name}', '${collection.posterPath}', '${collection.backdropPath}');")
    }

    println(s"Total de registros insertados: ${belongsToCollectionData.size}")
  } catch {
    case e: Exception => println(s"Error crítico: ${e.getMessage}")
  } finally {
    reader.close()
    writer.close()
  }
}
