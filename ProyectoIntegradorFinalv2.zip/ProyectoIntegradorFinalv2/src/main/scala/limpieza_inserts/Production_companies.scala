package limpieza_inserts

import com.github.tototoshi.csv.{CSVReader, DefaultCSVFormat}
import json_case_class.Companie
import play.api.libs.json.*
import utilidades.EscapeCaracteresEspeciales.limpiarJson

import java.io.{File, PrintWriter}
import scala.collection.mutable.ListBuffer
import scala.util.{Failure, Success, Try}

object Production_companies extends App {
  val rutaCsv = "data/pi_movies_complete.csv"
  val rutaArchivoSql = "data/inserts_production_companies.sql"

  implicit val csvFormat: DefaultCSVFormat = new DefaultCSVFormat {
    override val delimiter = ';'
  }

  val reader = CSVReader.open(new File(rutaCsv))
  val writer = new PrintWriter(new File(rutaArchivoSql))

  try {
    val datos = reader.allWithHeaders()

    val datosFiltrados = datos.filter { fila =>
      val columnasExcluyendoId = fila - "id"
      columnasExcluyendoId.values.exists(_.trim.nonEmpty) &&
        !columnasExcluyendoId.values.forall(_.trim.toLowerCase == "<unset>")
    }.distinct

    println(s"Total de filas después de filtrar: ${datosFiltrados.size}")

    val companiesList = new ListBuffer[Companie]()
    val movieCompaniesList = new ListBuffer[(Int, Int)]()

    datosFiltrados.foreach { fila =>
      for {
        movieId <- Try(fila("id").trim.toInt).toOption
        jsonStr = fila.getOrElse("production_companies", "").trim if jsonStr.nonEmpty && jsonStr != "\"\""
        jsonLimpio = limpiarJson(jsonStr).replaceAll("'", "\"")
        jsonArray <- Try(Json.parse(jsonLimpio).as[JsArray]).toOption
      } jsonArray.value.foreach { obj =>
        obj.validate[Companie] match {
          case JsSuccess(company, _) =>
            companiesList += company
            movieCompaniesList += ((movieId, company.id))
          case JsError(errors) =>
            println(s"Error en el JSON de production_companies: $errors")
        }
      }
    }

    try {
      writer.println("-- Inserts para la tabla companies")
      companiesList.groupBy(_.id).foreach { case (idCompany, companyList) =>
        val company = companyList.head
        val nameEscaped = company.name.replace("'", "''")
        writer.println(s"INSERT INTO company (id_company, company_name) VALUES ($idCompany, '$nameEscaped');")
      }

      writer.println("\n-- Inserts para la tabla movie_companies")
      movieCompaniesList.distinct.foreach { case (movieId, companyId) =>
        writer.println(s"INSERT INTO moviecompanies (movie_id, id_company) VALUES ($movieId, $companyId);")
      }

      println("Archivo SQL generado exitosamente: inserts_production_companies.sql")
    } catch {
      case e: Exception => println(s"Error al escribir el archivo SQL: ${e.getMessage}")
    } finally {
      writer.close()
    }

  } catch {
    case e: Exception => println(s"Error crítico: ${e.getMessage}")
  } finally {
    reader.close()
  }
}