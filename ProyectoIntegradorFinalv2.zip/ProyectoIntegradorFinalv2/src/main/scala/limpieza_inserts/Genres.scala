package limpieza_inserts

import com.github.tototoshi.csv.{CSVReader, DefaultCSVFormat}
import json_case_class.Genre
import json_cc_modelo_logico.MovieGenre
import play.api.libs.json.*
import utilidades.EscapeCaracteresEspeciales.limpiarJson

import java.io.{File, PrintWriter}
import scala.collection.mutable.ListBuffer
import scala.util.{Failure, Success, Try}

object Genres extends App {
  val rutaCsv = "data/pi_movies_complete.csv"
  val rutaArchivoSql = "data/insertsGenres.sql"

  implicit val csvFormat: DefaultCSVFormat = new DefaultCSVFormat {
    override val delimiter = ';'
  }

  val reader = CSVReader.open(new File(rutaCsv))
  val writer = new PrintWriter(new File(rutaArchivoSql))

  try {
    val datos = reader.allWithHeaders()

    val datosFiltrados = datos.filter { fila =>
      val columnasExcluyendoId = fila - "id"
      columnasExcluyendoId.values.exists(_.trim.nonEmpty) &&
        !columnasExcluyendoId.values.forall(_.trim.toLowerCase == "<unset>")
    }.distinct

    println(s"Total de filas después de filtrar: ${datosFiltrados.size}")

    val genresList = new ListBuffer[Genre]()
    val movieGenresList = new ListBuffer[MovieGenre]()

    datosFiltrados.foreach { fila =>
      for {
        movieId <- Try(fila("id").trim.toInt).toOption
        jsonStr = fila.getOrElse("genres", "").trim if jsonStr.nonEmpty && jsonStr != "\"\""
        jsonLimpio = limpiarJson(jsonStr).replaceAll("'", "\"")
        jsonArray <- Try(Json.parse(jsonLimpio).as[List[JsObject]]).toOption
      } jsonArray.foreach { jsonObj =>
        jsonObj.validate[Genre] match {
          case JsSuccess(genre, _) =>
            genresList += genre
            movieGenresList += MovieGenre(movieId, genre.id)
          case JsError(errors) =>
            println(s"Error en el JSON de género: $errors")
        }
      }
    }

    try {
      writer.println("-- Inserts para la tabla genres")
      genresList.groupBy(_.id).foreach { case (idGenre, genreList) =>
        val genre = genreList.head
        val nameEscaped = genre.name.replace("'", "''")
        writer.println(
          s"INSERT INTO genres (id, genres_name) VALUES ($idGenre, '$nameEscaped');"
        )
      }

      writer.println("\n-- Inserts para la tabla movieGenres")
      movieGenresList.distinct.foreach { relation =>
        writer.println(s"INSERT INTO movieGenres (movie_id, genre_id) VALUES (${relation.movieId}, ${relation.genreId});")
      }

      println("Archivo SQL generado exitosamente: insertsGenres.sql")
    } catch {
      case e: Exception => println(s"Error al escribir el archivo SQL: ${e.getMessage}")
    } finally {
      writer.close()
    }

  } catch {
    case e: Exception => println(s"Error crítico: ${e.getMessage}")
  } finally {
    reader.close()
  }
}