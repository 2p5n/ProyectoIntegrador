package limpieza_inserts

import com.github.tototoshi.csv.{CSVReader, DefaultCSVFormat}
import play.api.libs.json.{JsObject, Json}
import utilidades.EscapeCaracteresEspeciales.limpiarJson

import java.io.{File, PrintWriter}
import scala.util.{Failure, Success, Try}

object Spoken_languages extends App {
  val rutaCsv = "data/pi_movies_complete.csv"
  val rutaArchivoSql = "data/inserts_spoken_languages.sql"

  implicit val csvFormat: DefaultCSVFormat = new DefaultCSVFormat {
    override val delimiter = ';'
  }

  val reader = CSVReader.open(new File(rutaCsv))
  val writer = new PrintWriter(new File(rutaArchivoSql))

  try {
    val datos = reader.allWithHeaders()

    val datosFiltrados = datos.filter { fila =>
      val columnasExcluyendoId = fila - "id"
      columnasExcluyendoId.values.exists(_.trim.nonEmpty) &&
        !columnasExcluyendoId.values.forall(_.trim.toLowerCase == "<unset>")
    }.distinct

    println(s"Total de filas después de filtrar: ${datosFiltrados.size}")

    val spokenLanguagesList = scala.collection.mutable.Set[(String, String)]()
    val movieSpokenLanguagesList = scala.collection.mutable.ListBuffer[(Int, String)]()

    datosFiltrados.foreach { fila =>
      for {
        movieId <- Try(fila("id").trim.toInt).toOption
        jsonStr = fila.getOrElse("spoken_languages", "").trim if jsonStr.nonEmpty && jsonStr != "\"\""
        jsonLimpio = limpiarJson(jsonStr).replaceAll("'", "\"")
        jsonArray <- Try(Json.parse(jsonLimpio).as[List[JsObject]]).toOption
      } jsonArray.foreach { langObj =>
        val isoCode = (langObj \ "iso_639_1").asOpt[String].filter(_.nonEmpty).getOrElse("null")
        val name = (langObj \ "name").asOpt[String].filter(_.nonEmpty).getOrElse("null")
        spokenLanguagesList.add((isoCode, name))
        movieSpokenLanguagesList.append((movieId, isoCode))
      }
    }

    try {
      writer.println("-- Inserts para la tabla spoken_languages")
      spokenLanguagesList.foreach { case (isoCode, name) =>
        val nameEscaped = name.replace("'", "''")
        writer.println(s"INSERT INTO languages (iso_639_1, languages_name) VALUES ('$isoCode', '$nameEscaped');")
      }

      writer.println("\n-- Inserts para la tabla movieSpokenLanguages")
      movieSpokenLanguagesList.distinct.foreach { case (movieId, isoCode) =>
        writer.println(s"INSERT INTO movielanguages (movie_id, iso_639_1) VALUES ($movieId, '$isoCode');")
      }

      println("Archivo SQL generado exitosamente: inserts_spoken_languages.sql")
    } catch {
      case e: Exception => println(s"Error al escribir el archivo SQL: ${e.getMessage}")
    } finally {
      writer.close()
    }
  } catch {
    case e: Exception => println(s"Error crítico: ${e.getMessage}")
  } finally {
    reader.close()
    }
}