package limpieza_inserts

import com.github.tototoshi.csv.{CSVReader, DefaultCSVFormat}
import json_case_class.Keyword
import play.api.libs.json.*
import utilidades.EscapeCaracteresEspeciales.limpiarJson

import java.io.{File, PrintWriter}
import scala.collection.mutable.ListBuffer
import scala.util.{Failure, Success, Try}

object Keywords extends App {
  val rutaCsv = "data/pi_movies_complete.csv"
  val rutaArchivoSql = "data/insertsKeywords.sql"

  implicit val csvFormat: DefaultCSVFormat = new DefaultCSVFormat {
    override val delimiter = ';'
  }

  val reader = CSVReader.open(new File(rutaCsv))
  val writer = new PrintWriter(new File(rutaArchivoSql))

  try {
    val datos = reader.allWithHeaders()

    val datosFiltrados = datos.filter { fila =>
      val columnasExcluyendoId = fila - "id"
      columnasExcluyendoId.values.exists(_.trim.nonEmpty) &&
        !columnasExcluyendoId.values.forall(_.trim.toLowerCase == "<unset>")
    }.distinct

    println(s"Total de filas después de filtrar: ${datosFiltrados.size}")

    val keywordsList = new ListBuffer[Keyword]()
    val movieKeywordsList = new ListBuffer[(Int, Int)]()

    datosFiltrados.foreach { fila =>
      for {
        movieId <- Try(fila("id").trim.toInt).toOption
        jsonStr = fila.getOrElse("keywords", "").trim if jsonStr.nonEmpty && jsonStr != "\"\""
        jsonLimpio = limpiarJson(jsonStr).replaceAll("'", "\"")
        jsonArray <- Try(Json.parse(jsonLimpio).as[JsArray]).toOption
      } jsonArray.value.foreach { obj =>
        obj.validate[Keyword] match {
          case JsSuccess(keyword, _) =>
            keywordsList += keyword
            movieKeywordsList += ((movieId, keyword.id))
          case JsError(errors) =>
            println(s"Error en el JSON de keywords: $errors")
        }
      }
    }

    try {
      writer.println("-- Inserts para la tabla keywords")
      keywordsList.groupBy(_.id).foreach { case (idKeyword, keywordList) =>
        val keyword = keywordList.head
        val nameEscaped = keyword.name.replace("'", "''")
        writer.println(s"INSERT INTO keywords (id_keywords, keywords_name) VALUES ($idKeyword, '$nameEscaped');")
      }

      writer.println("\n-- Inserts para la tabla movieKeywords")
      movieKeywordsList.distinct.foreach { case (movieId, keywordId) =>
        writer.println(s"INSERT INTO movieKeywords (movie_id, id_keywords) VALUES ($movieId, $keywordId);")
      }

      println("Archivo SQL generado exitosamente: insertsKeywords.sql")
    } catch {
      case e: Exception => println(s"Error al escribir el archivo SQL: ${e.getMessage}")
    } finally {
      writer.close()
    }

  } catch {
    case e: Exception => println(s"Error crítico: ${e.getMessage}")
  } finally {
    reader.close()
  }
}
